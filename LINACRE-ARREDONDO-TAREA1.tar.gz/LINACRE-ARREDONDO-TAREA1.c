/*
+---+-------+---+
| A | B   B | C |
|               |
| A | B   B | C |
+---+-------+---+
| D | E   E | F |
+---+-------+---+
| G | H | I | J |
|   +---+---+   |
| G |       | J |
+---+-------+---+
*/

#include<stdio.h>
#include<string.h>

int main() {

	char tablero[5][4]={{' ',' ',' ',' '},{' ',' ',' ',' '},{' ',' ',' ',' '},
			   {' ',' ',' ',' '},{' ',' ',' ',' '}};
	
	// Ingreso posición de cada ficha
	int A[2][2] = {{0,0},{1,0}};
	tablero[A[0][0]][A[0][1]] = 'A';
	tablero[A[1][0]][A[1][1]] = 'A';
	
	int B[4][2] = {{0,1},{0,2},{1,1},{1,2}};
	tablero[B[0][0]][B[0][1]] = 'B';
	tablero[B[1][0]][B[1][1]] = 'B';
	tablero[B[2][0]][B[2][1]] = 'B';
	tablero[B[3][0]][B[3][1]] = 'B';
	
	int C[2][2] = {{0,3},{1,3}};
	tablero[C[0][0]][C[0][1]] = 'C';
	tablero[C[1][0]][C[1][1]] = 'C';

	int D[1][2] = {{2,0}};
	tablero[D[0][0]][D[0][1]] = 'D';
	
	int E[2][2] = {{2,1},{2,2}};
	tablero[E[0][0]][E[0][1]] = 'E';
	tablero[E[1][0]][E[1][1]] = 'E';
	
	int F[1][2] = {{2,3}};
	tablero[F[0][0]][F[0][1]] = 'F';
	
	int G[2][2] = {{3,0},{4,0}};
	tablero[G[0][0]][G[0][1]] = 'G';
	tablero[G[1][0]][G[1][1]] = 'G';
	
	int H[1][2] = {{3,1}};
	tablero[H[0][0]][H[0][1]] = 'H';
	
	int I[1][2] = {{3,2}};
	tablero[I[0][0]][I[0][1]] = 'I';
	
	int J[2][2] = {{3,3},{4,3}};
	tablero[J[0][0]][J[0][1]] = 'J';
	tablero[J[1][0]][J[1][1]] = 'J';

	//Imprimo tablero 
	
	printf(" ------------\n");
	for (int i=0;i<5;i++){ //filas
		printf("|");
		for(int j=0;j<4;j++){ //columnas
			//tablero[i][j]='0'; //caracter 0
			printf("%2c ", tablero[i][j]); //
		}	
		printf("|\n");	
	}
	printf(" ------------\n");
	
	
	//printf("%2c \n", tablero[4][0]); // Esto imprime G
	//printf("%2d \n", H[0][0]); //Esto imprime 3
	
	//Defino variables a utilizar
	char input[10];
	char pieza, direc;
	int pasos;
	char h, v;
	char PZ[]={'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};
	char pz[]={'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
	char DR[]={'N', 'S', 'E', 'O'};
	char dr[]={'n', 's', 'e', 'o'};
	int PS[]={0,50}; //0 es vacio, es decir, 1 paso. 50 es 2, es decir, 2 pasos.
	int juego=1;
	
	
	//while true..
	while(juego<=1) {
	
		scanf("%s", input);
		pieza=input[0]; 
		direc=input[1];
		pasos=input[2]; 
		
		//printf("%d\n", pasos);
		printf("%c\n", tablero[4][1]);

		h=0, v=0;
		if(pasos==PS[0]){
			if(direc==DR[0] || direc==dr[0]){
				v=-1; //Norte
			}
			else if(direc==DR[1] || direc==dr[1]){
				v=1; //Sur
			}
			else if(direc==DR[2] || direc==dr[2]){
				h=1; //Este
			}
			else if(direc==DR[3] || direc==dr[3]){
				h=-1; //Oeste
			}
		}
		
		else if(pasos==PS[1]){
			if(direc==DR[0] || direc==dr[0]){
				v=-2; //Norte
			}
			else if(direc==DR[1] || direc==dr[1]){
				v=2; //Sur
			}
			else if(direc==DR[2] || direc==dr[2]){
				h=2; //Este
			}
			else if(direc==DR[3] || direc==dr[3]){
				h=-2; //Oeste
			}			
		
		}
		
		
		// Asigno nuevas posiciones a piezas segun direccion ingresada
		if(pieza==PZ[0] || pieza==pz[0]){ //A
			
			//VERIFICACION DE MOVIMIENTO PIEZA A
			if(tablero[A[0][0]+v][A[0][1]+h] != ' ' && tablero[A[1][0]+v][A[1][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{
				tablero[A[0][0]][A[0][1]] = ' '; //Hago vacio el anterior
				tablero[A[1][0]][A[1][1]] = ' ';
			
				A[0][0] = A[0][0] + v; //A de arriba
				A[1][0] = A[1][0] + v; //A de abajo
				
				A[0][1] = A[0][1] + h;
				A[1][1] = A[1][1] + h;
				
				tablero[A[0][0]][A[0][1]] = 'A'; //Lleno el espacio nuevo espacio
				tablero[A[1][0]][A[1][1]] = 'A';				
			}
			
			
			//printf("Estoy en el caso de pieza = A\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");	
		}
		
		
		else if(pieza==PZ[1] || pieza==pz[1]){ //B
			
			//VERIFICACION DE MOVIMIENTO PIEZA B
			if((tablero[B[0][0]+v][B[0][1]+h] != ' ' && tablero[B[0][0]+v][B[0][1]+h] != 'B') 
			|| (tablero[B[1][0]+v][B[1][1]+h] != ' ' && tablero[B[1][0]+v][B[1][1]+h] != 'B')
			|| (tablero[B[2][0]+v][B[2][1]+h] != ' ' && tablero[B[2][0]+v][B[2][1]+h] != 'B')
			|| (tablero[B[3][0]+v][B[3][1]+h] != ' ' && tablero[B[3][0]+v][B[3][1]+h] != 'B')){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}			
			
			else{
				tablero[B[0][0]][B[0][1]] = ' ';
				tablero[B[1][0]][B[1][1]] = ' ';
				tablero[B[2][0]][B[2][1]] = ' ';
				tablero[B[3][0]][B[3][1]] = ' ';
				
				B[0][0] = B[0][0] + v;
				B[1][0] = B[1][0] + v;
				B[2][0] = B[2][0] + v;
				B[3][0] = B[3][0] + v;
				
				B[0][1] = B[0][1] + h;
				B[1][1] = B[1][1] + h;
				B[2][1] = B[2][1] + h;
				B[3][1] = B[3][1] + h;
				
				tablero[B[0][0]][B[0][1]] = 'B';
				tablero[B[1][0]][B[1][1]] = 'B';
				tablero[B[2][0]][B[2][1]] = 'B';
				tablero[B[3][0]][B[3][1]] = 'B';
			}
			
			
			//printf("Estoy en el caso de pieza = B\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");
		}
		
		
		else if(pieza==PZ[2] || pieza==pz[2]){ //C
		
			//VERIFICACION DE MOVIMIENTO PIEZA C
			if(tablero[C[0][0]+v][C[0][1]+h] != ' ' || tablero[C[1][0]+v][C[1][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{
				tablero[C[0][0]][C[0][1]] = ' ';
				tablero[C[1][0]][C[1][1]] = ' ';
				
				C[0][0] = C[0][0] + v;
				C[1][0] = C[1][0] + v;
				
				C[0][1] = C[0][1] + h;
				C[1][1] = C[1][1] + h;
				
				tablero[C[0][0]][C[0][1]] = 'C';
				tablero[C[1][0]][C[1][1]] = 'C';			
			}
			
			
			//printf("Estoy en el caso de pieza = C\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");
			
		}
		
		
		else if(pieza==PZ[3] || pieza==pz[3]){ //D
			
			//VERIFICACION DE MOVIMIENTO PIEZA D
			if(tablero[D[0][0]+v][D[0][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");		
			}
			
			else{
				tablero[D[0][0]][D[0][1]] = ' '; //Hago vacio el anterior
				
				D[0][0] = D[0][0] + v;
				D[0][1] = D[0][1] + h;
				
				tablero[D[0][0]][D[0][1]] = 'D'; //actualizo el nuevo lugar
			}
			
			
			//printf("Estoy en el caso de pieza = D\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");			
			
		}
		
		
		else if(pieza==PZ[4] || pieza==pz[4]){ //E

			//VERIFICACION DE MOVIMIENTO PIEZA E
			if(tablero[E[0][0]+v][E[0][1]+h] != ' ' || tablero[E[1][0]+v][E[1][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{
				tablero[E[0][0]][E[0][1]] = ' '; //Hago vacio el anterior
				tablero[E[1][0]][E[1][1]] = ' ';
				
				E[0][0] = E[0][0] + v;
				E[1][0] = E[1][0] + v;
				
				E[0][1] = E[0][1] + h;
				E[1][1] = E[1][1] + h;
				
				tablero[E[0][0]][E[0][1]] = 'E'; //Hago vacio el anterior
				tablero[E[1][0]][E[1][1]] = 'E';			
			}
			

			//printf("Estoy en el caso de pieza = E\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");			
			
		}
		
		
		else if(pieza==PZ[5] || pieza==pz[5]){ //F

			//VERIFICACION DE MOVIMIENTO PIEZA F
			if(tablero[F[0][0]+v][F[0][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{
				tablero[F[0][0]][F[0][1]] = ' '; //Hago vacio el anterior
				
				F[0][0] = F[0][0] + v;
				F[0][1] = F[0][1] + h;
				
				tablero[F[0][0]][F[0][1]] = 'F'; //actualizo el nuevo lugar
			}
			
			
			//printf("Estoy en el caso de pieza = F\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");			
			
		}
		
		
		else if(pieza==PZ[6] || pieza==pz[6]){ //G
			
			//VERIFICACION DE MOVIMIENTO PIEZA G
			if(tablero[G[0][0]+v][G[0][1]+h] != ' ' || tablero[G[1][0]+v][G[1][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{
				tablero[G[0][0]][G[0][1]] = ' '; //Hago vacio el anterior
				tablero[G[1][0]][G[1][1]] = ' ';
				
				G[0][0] = G[0][0] + v;
				G[1][0] = G[1][0] + v;
				
				G[0][1] = G[0][1] + h;
				G[1][1] = G[1][1] + h;
				
				tablero[G[0][0]][G[0][1]] = 'G'; //Hago vacio el anterior
				tablero[G[1][0]][G[1][1]] = 'G';
			}
			
			
			//printf("Estoy en el caso de pieza = G\n");


			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");
				
		}
		
		
		else if(pieza==PZ[7] || pieza==pz[7]){ //H

			//VERIFICACION DE MOVIMIENTO PIEZA H
			if(tablero[H[0][0]+v][H[0][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{		
				tablero[H[0][0]][H[0][1]] = ' '; //Hago vacio el anterior
				
				H[0][0] = H[0][0] + v;
				H[0][1] = H[0][1] + h;
				tablero[H[0][0]][H[0][1]] = 'H'; //actualizo el nuevo lugar
			}

			//printf("Estoy en el caso de pieza = H\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");			
			
		} 
		
		
		else if (pieza==PZ[8] || pieza==pz[8]) { //I		

			//VERIFICACION DE MOVIMIENTO PIEZA I
			if(tablero[I[0][0]+v][I[0][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{		
				tablero[I[0][0]][I[0][1]] = ' '; //Hago vacio el anterior

				I[0][0] = I[0][0] + v;
				I[0][1] = I[0][1] + h;
				
				tablero[I[0][0]][I[0][1]] = 'I'; //actualizo el nuevo lugar
			}
			
			//printf("Estoy en el caso de pieza = I\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");			
		}
		
			
		else if(pieza==PZ[9] || pieza==pz[9]){ //J

			
			if(tablero[J[0][0]+v][J[0][1]+h] != ' ' && tablero[J[1][0]+v][J[1][1]+h] != ' '){
				printf("Movimiento invalido. Intente nuevamente. \n");
			}
			
			else{
				tablero[J[0][0]][J[0][1]] = ' '; //Hago vacio el anterior
				tablero[J[1][0]][J[1][1]] = ' ';
				
				J[0][0] = J[0][0] + v;
				J[1][0] = J[1][0] + v;
				
				J[0][1] = J[0][1] + h;
				J[1][1] = J[1][1] + h;
				
				tablero[J[0][0]][J[0][1]] = 'J'; //Hago vacio el anterior
				tablero[J[1][0]][J[1][1]] = 'J';
			}
			
			//printf("Estoy en el caso de pieza = J\n");
			
			
			printf(" ------------\n");
			for (int i=0;i<5;i++){ //filas
				printf("|");
				for(int j=0;j<4;j++){ //columnas
					printf("%2c ", tablero[i][j]); //
				}	
				printf("|\n");	
			}
			printf(" ------------\n");			
			
		}
		
		
		}
			
	return 0;
}
	




